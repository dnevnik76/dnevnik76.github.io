// Устанавливаем начальное состояние переключателя
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ 'isEnabled': true });
});

// Обрабатываем запросы на включение/выключение
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'toggle') {
    chrome.storage.local.get('isEnabled', (result) => {
      const newState = !result.isEnabled;
      chrome.storage.local.set({ 'isEnabled': newState });
      sendResponse({ isEnabled: newState });
    });
    return true; // Позволяет отправить ответ асинхронно
  }
});
