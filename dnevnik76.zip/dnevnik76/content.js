function modifyContent() {
  chrome.storage.local.get('isEnabled', (result) => {
    if (result.isEnabled !== false) {
      const url = window.location.href;

      if (url === "https://my.dnevnik76.ru/") {
        fetch(chrome.runtime.getURL('home.html'))
          .then(response => response.text())
          .then(html => {
            document.open();
            document.write(html);
            document.close();
          })
          .catch(error => console.error('Ошибка загрузки home.html:', error));
      } 
      else if (url.startsWith("https://my.dnevnik76.ru/marks/current/")) {
        const metaViewport = document.createElement('meta');
        metaViewport.name = "viewport";
        metaViewport.content = "width=device-width, initial-scale=1";
        document.head.appendChild(metaViewport);

        const metaLang = document.createElement('meta');
        metaLang.setAttribute('http-equiv', 'Content-Language');
        metaLang.content = "ru";
        document.head.appendChild(metaLang);

        const linkElements = document.querySelectorAll('link[rel="stylesheet"]');
        linkElements.forEach(link => {
          if (link.href.includes('/static/css/')) {
            link.href = chrome.runtime.getURL('mark.css');
          }
        });

        const agrStatImg = document.querySelector('header img.agr_stat');
        if (agrStatImg) {
          agrStatImg.remove();
        }

        const headerH1 = document.querySelector('header h1');
        if (headerH1 && headerH1.textContent.includes('Региональный интернет-дневник 4.1')) {
          headerH1.remove();
        }

        const eduYearSpan = document.getElementById('eduyear');
        if (eduYearSpan) {
          eduYearSpan.remove();
        }

        const authInfoDiv = document.getElementById('auth_info');
        if (authInfoDiv) {
          authInfoDiv.remove();
        }

        const menuItems = document.querySelectorAll('nav a');
        menuItems.forEach(item => {
          if (['Домашнее задание', 'Учителя', 'Сообщения', 'Файлы'].includes(item.textContent.trim())) {
            item.remove();
          }
        });

        const comments = document.createTreeWalker(document, NodeFilter.SHOW_COMMENT, null, false);
        let commentNode;
        while (commentNode = comments.nextNode()) {
          if (commentNode.nodeValue.includes('Yandex.Metrika') || commentNode.nodeValue.includes('Ads system')) {
            commentNode.remove();
          }
        }
      }
    }
  });
}

window.addEventListener('load', modifyContent);
