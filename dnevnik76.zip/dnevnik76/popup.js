document.addEventListener('DOMContentLoaded', () => {
  const toggleSwitch = document.getElementById('toggle-switch');

  // Загружаем текущее состояние переключателя
  chrome.storage.local.get('isEnabled', (result) => {
    toggleSwitch.checked = result.isEnabled !== false;
  });

  // Обрабатываем изменение состояния переключателя
  toggleSwitch.addEventListener('change', () => {
    const newState = toggleSwitch.checked;
    chrome.runtime.sendMessage({ action: 'toggle' }, (response) => {
      if (response.isEnabled !== undefined) {
        toggleSwitch.checked = response.isEnabled;
      }
    });
  });
});
